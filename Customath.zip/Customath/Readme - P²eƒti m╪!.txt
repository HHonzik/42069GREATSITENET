Obsah tohoto zipu:
    -Program Customath (Customath.bat)
    -Customath s malování (start with mspaint.bat)
    -Vytvoření zástupce nebo ikony na ploše (create shortcut.txt)
    -Tento soubor (Readme - Přečti mě!.txt)
    -Ikona (icon.ico)
Obsah progarmu Customath:
    -Sčítaní a odčítaní
    -Násobení a dělení
    -Násobení a dělení mimo obsah malé násobilky
    -Převod jednotky délky
    -Nastavení:
        -Největší číslo v příkladech
        -Jestli tam bude odčítaní a dělení
        -Jestli se nemaj vymazat výsledky po zavření nebo ukončení (ne programu)
        -Nastavení textu pro výsledky.